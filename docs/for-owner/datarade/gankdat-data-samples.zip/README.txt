gankdat data samples — 25 live records per dataset, pulled from production on 2026-09-20 (v0.7.0).
Each file is the exact JSON shape returned inside the API envelope ("data": [...]) for GET https://gankdat.com/v1/data/<dataset>.
Field definitions: see gankdat-data-dictionary.pdf. Licences: see https://gankdat.com/terms.
Contact: info@gankdat.com
